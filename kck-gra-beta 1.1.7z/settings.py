WIDTH = 800
HEIGHT = 600

p1_pos = 200
p2_pos = 400
p_width = 30
p_height = 40


b_pos_y = 400
b_pos_x = 255
mob_size = 25
round_score = 1000
mob_point = 5

bullet_timer = 1
bullet_amount = 12
bullet_dmg = 50
bullet_knockout = 6

RED = (255,0,0)
DARK_RED = (128, 0, 0)
GREEN = (0,255,0)
BLUE = (0,0,255)
BLACK = (0,0,0)
WHITE = (255,255,255)